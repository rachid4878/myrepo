<?php
// src/AppBundle/Entity/Task.php
namespace AppBundle\Entity;

class Task
{
    protected $nr1;
    protected $nr2;
    protected $operator;


	public function getNr1(){return $this->task;}
    public function setNr1($task){$this->task = $task;}
	public function getNr2(){return $this->task;}
    public function setNr2($task){$this->task = $task;}

	public function getOperator(){return $this->task;}
    public function setOperator($task){$this->task = $task;}
	
	
	
}