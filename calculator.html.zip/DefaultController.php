<?php

// src/AppBundle/Controller/DefaultController.php
namespace AppBundle\Controller;

use AppBundle\Entity\Task;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;

use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;


class DefaultController extends Controller
{
	
	 /**
     * @Route("/calculator")
     */

	 public function newAction(Request $request)
    {

	$task = new Task();
        $task->setNr1(0);
        $task->setNr2(0);
        $task->setOperator(0);

      $form = $this->createFormBuilder($task)
	        ->add('nr1', TextType::class)
            ->add('operator', ChoiceType::class, array('choices'  => array('+' => '+','-' => '-','*' => '*','/' => '/')))
	        ->add('nr2', TextType::class)			
            ->add('save', SubmitType::class, array('label' => 'Calculate'))
            ->getForm();		
			

	    $form->handleRequest($request);

		$data = '';

		
if ($form->isSubmitted() && $form->isValid()) {		
		
		$nr1 = $form->get('nr1')->getData();	
		$nr2 = $form->get('nr2')->getData();	
		$operator = $form->get('operator')->getData();	

if($nr2==0 && $operator=='/'){$data = "Division by 0 not allowed";}else{
	
		switch ($operator) {
        case '+':
            $data = $nr1 + $nr2;
            break;
        case '-':
            $data = $nr1 - $nr2;
            break;
        case '*':
            $data = $nr1 * $nr2;
            break;
        case '/':
            $data = $nr1 / $nr2;
            break;
    }
	
}
}

	
        return $this->render('default/calculator.html.twig', array(
		    'number' =>$data,
            'form' => $form->createView(),
        ));
		
    }
	
	
	   
	   
	
}






